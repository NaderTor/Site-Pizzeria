@extends('modele')

@section('contents')
    <p>Premiere page</p>
    
@section('contents')
<style>

    table,
    th,
    td {
        padding: 6px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }


    .BM,.Ajoubutton,.BS, .Ajout{
         background-color: blue;
        border: none;
        color: white;
        padding: 2px 5px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
    }
</style>


@auth
    <table>
        <th>id</th>
        <th>Nom</th>
        <th>description</th>
        <th>Prix</th>

        @foreach($pizzas as $pizza)
            <tr><td>{{$pizza->id}}</td><td>{{$pizza->nom}}</td><td>{{$pizza->description}}</td><td>{{$pizza->prix}}e</td> 
            <td><a href="{{route('ajouterPanier',['nom' => $pizza->nom])}}" class="Ajout" >Ajouter au panier</a></td>
            </tr>
        @endforeach
    </table>
@endauth

@endsection

@endsection
