

@section('contents')
<p>Panier d'achat</p>

<p><a href {{route('Pizza')}} class="Ret">Retour</a></p>
<style>
    table,
    th,
    td {
        padding: 6px;
        border: 3px solid black;
        border-collapse: collapse;
        
    }
</style>
<tr><td>Nom des pizzas</td> <td>quantité</td></tr>
<table>
@foreach ($paniers as $key=>$val )
    <tr><td>{{$key}}</td><td>{{$val}}</td>
        <td><a href={{route('augmenterLaQuantite',['nom'=>$key])}}>Augmenter</td>
    </tr>
@endforeach
</table>
<p>Prix Total: {{$prixTotal}}euros</p>