@extends('modele')

@section('contents')
    <p>PAGE ACCUIEL DES ADMINISTRATEUR</p>
    
@section('contents')
<style>

    table,
    th,
    td {
        padding: 6px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }


    .BM,.Ajoubutton,.BS, .Ajout{
         background-color: blue;
        border: none;
        color: white;
        padding: 2px 5px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
    }
</style>

@auth
    <table>
        <th>id</th>
        <th>Nom</th>
        <th>description</th>
        <th>Prix</th>

        @foreach($pizzas as $pizza)
            <tr><td>{{$pizza->id}}</td><td>{{$pizza->nom}}</td><td>{{$pizza->description}}</td><td>{{$pizza->prix}}e</td>
                <td><a href="{{route('deleteForm',['id'=>$pizza->id])}}" class="BS">Supprimer</a></td>
                <td><a href="{{route('modifyForm',['id'=>$pizza->id])}}" class="BM">Modifier</a></td>
                <td><a href="{{route('ajouterPanier')}}" class="Ajout">Ajouter au panier</a></td>
            </tr>
        @endforeach
    </table>
    <center>
            <p><a href="{{route('createForm')}}" class="Ajoubutton">Ajouter une Pizza</a></p>
    </center>
@endauth

@endsection



@endsection
