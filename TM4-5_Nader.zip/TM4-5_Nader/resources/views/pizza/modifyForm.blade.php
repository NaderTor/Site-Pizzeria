@extends('modele')

@section('title', 'Modifier une pizza')


@section('contents')

<form class="bg-light p-3 w-50 m-3" action="{{route('modify',['id'=>$pizzas->id])}}" method="post">
<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<form class="bg-light p-3 w-50 m-3" action="" method="post">
			<legend> Modifier une pizza </legend>

      <div class="form-group row mb-0">
				<label for="inputNom" class="col-6 col-form-label"> Nom </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="text" class="form-control" id="inputNom" style="width:93.5%" name="nom" value="{{$pizzas->nom}}">
				</div>
			</div>
            <div class="form-group row mb-0">
				<label for="inputNom" class="col-6 col-form-label"> Description </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="text" class="form-control" id="inputNom" style="width:93.5%" name="description" value="{{$pizzas->description}}">
				</div>
			</div>
             <div class="form-group row mb-0">
				<label for="inputNom" class="col-6 col-form-label"> Prix </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="text" class="form-control" id="inputNom" style="width:93.5%" name="prix" value="{{$pizzas->prix}}">
				</div>
			</div>
        <button type="submit" class="btn btn-primary col-4 mt-3" style="padding:10px; font-size:20px" value="Envoyer">Envoyer</button>
        @csrf
</form>
@endsection