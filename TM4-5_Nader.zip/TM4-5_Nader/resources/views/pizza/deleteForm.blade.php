@extends('modele')

@section('title','Supprimer')

@section('contenu')
    <p>Voulez-vous supprimer cette pizza ? </p>
    <form action="{{route('delete',['id'=>$pizzas->id])}}" method="post">
        <input type="submit" value="Oui">
        <input type="submit" value="Non">
        @csrf
    </form>
@endsection
 