@extends('modele')

@section('title','Liste des pizzas')

@section('contents')
    <table>
        @foreach($pizzas as $pizza)
            <tr><td>{{$pizza->id}}</td><td>{{$pizza->nom}}</td><td>{{$pizza->description}}</td><td>{{$pizza->prix}}</td>
                <td><a href="{{route('produits.suppForm',['id'=>$pizza->id])}}">Supprimer</a></td>
                <td><a href="{{route('produits.modForm',['id'=>$pizza->id])}}">Modifier</a></td>
            </tr>
        @endforeach
    </table>
@endsection
