<!DOCTYPE html>
<html>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <title>@yield('title', config('app.name'))</title>
    <style>
        .etat{background-color: lightblue;}
        .error {background-color: lightpink;}

        .LG{
        background-color: blue;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
        }

        .RE{
        background-color: blue;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
        }

        .LO{
        background-color: blue;
        border: none;
        color: white;
        padding: 2px 5px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
        }

        .MOD{
        background-color: blue;
        border: none;
        color: white;
        padding: 2px 5px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
        }

        .MM,.Pan{
        background-color: blue;
        border: none;
        color: white;
        padding: 2px 5px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
        }
    </style>
</head>
<body>
    @section('menu')
@guest()
    <center>
        <a href="{{route('login')}}" class="LG">Login</a>
        <a href="{{route('register')}}" class="RE">Enregistrement</a>
    </center
@endguest


        @auth
            <a href="{{route('logout')}}" class="LO">Deconnexion</a>
            <p>Bonjour {{ Auth::user()}} </p>
            <a href="{{route('modifierForm')}}" class="MOD">Changer le mot de passe</a>
            <a href="{{route('afficherPanier')}}" class="Pan"> Aller au panier</a>
            <a href="{{route('admin_home')}}" class="MM"> Modifier le menu</a>
        @endauth

    @show
    @section('etat')
        @if(session()->has('etat'))
            <p class="etat">{{session()->get('etat')}}</p>
        @endif
    @show
    @section('errors')
        @if ($errors->any())
            <div class="error">
                <ul>
                    @foreach ($errors->all() as $error )
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @show
        @yield('contents')
    </body>
</html>

    