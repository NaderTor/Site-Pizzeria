<?php $__env->startSection('title', 'Ajouter une pizza'); ?>

<?php $__env->startSection('contents'); ?>

<form class="bg-light p-3 w-50 m-3" action="" method="post">
<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<form class="bg-light p-3 w-50 m-3" action="" method="post">
			<legend> Ajoutez une pizza </legend>

      <div class="form-group row mb-0">
				<label for="inputNom" class="col-6 col-form-label"> Nom </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="text" class="form-control" id="inputNom" style="width:93.5%" name="nom" value="<?php echo e(old('nom')); ?>">
				</div>
			</div>
            <div class="form-group row mb-0">
				<label for="inputNom" class="col-6 col-form-label"> Description </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="text" class="form-control" id="inputNom" style="width:93.5%" name="description" value="<?php echo e(old('description')); ?>">
				</div>
			</div>
             <div class="form-group row mb-0">
				<label for="inputNom" class="col-6 col-form-label"> Prix </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="text" class="form-control" id="inputNom" style="width:93.5%" name="prix" value="<?php echo e(old('prix')); ?>">
				</div>
			</div>
        <button type="submit" class="btn btn-primary col-4 mt-3" style="padding:10px; font-size:20px" value="Envoyer">Envoyer</button>
        <?php echo csrf_field(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nadertorjemane/Stock_MAMP/TM4-5/resources/views/pizza/createForm.blade.php ENDPATH**/ ?>