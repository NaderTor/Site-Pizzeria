

<?php $__env->startSection('contents'); ?>
<p>Panier d'achat</p>

<p><a href <?php echo e(route('Pizza')); ?> class="Ret">Retour</a></p>
<style>
    table,
    th,
    td {
        padding: 6px;
        border: 3px solid black;
        border-collapse: collapse;
        
    }
</style>
<tr><td>Nom des pizzas</td> <td>quantité</td></tr>
<table>
<?php $__currentLoopData = $paniers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr><td><?php echo e($key); ?></td><td><?php echo e($val); ?></td>
        <td><a href=<?php echo e(route('augmenterLaQuantite',['nom'=>$key])); ?>>Augmenter</td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<p>Prix Total: <?php echo e($prixTotal); ?>euros</p><?php /**PATH /Users/nadertorjemane/Stock_MAMP/TM4-5/resources/views/panier.blade.php ENDPATH**/ ?>