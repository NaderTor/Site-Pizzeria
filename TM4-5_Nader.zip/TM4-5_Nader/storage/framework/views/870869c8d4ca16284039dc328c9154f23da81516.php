<!DOCTYPE html>
<html>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <title><?php echo $__env->yieldContent('title', config('app.name')); ?></title>
    <style>
        .etat{background-color: lightblue;}
        .error {background-color: lightpink;}

        .LG{
        background-color: blue;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
        }

        .RE{
        background-color: blue;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
        }

        .LO{
        background-color: blue;
        border: none;
        color: white;
        padding: 2px 5px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
        }

        .MOD{
        background-color: blue;
        border: none;
        color: white;
        padding: 2px 5px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
        }

        .MM,.Pan{
        background-color: blue;
        border: none;
        color: white;
        padding: 2px 5px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
        }
    </style>
</head>
<body>
    <?php $__env->startSection('menu'); ?>
<?php if(auth()->guard()->guest()): ?>
    <center>
        <a href="<?php echo e(route('login')); ?>" class="LG">Login</a>
        <a href="<?php echo e(route('register')); ?>" class="RE">Enregistrement</a>
    </center
<?php endif; ?>


        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('logout')); ?>" class="LO">Deconnexion</a>
            <p>Bonjour <?php echo e(Auth::user()); ?> </p>
            <a href="<?php echo e(route('modifierForm')); ?>" class="MOD">Changer le mot de passe</a>
            <a href="<?php echo e(route('afficherPanier')); ?>" class="Pan"> Aller au panier</a>
            <a href="<?php echo e(route('admin_home')); ?>" class="MM"> Modifier le menu</a>
        <?php endif; ?>

    <?php echo $__env->yieldSection(); ?>
    <?php $__env->startSection('etat'); ?>
        <?php if(session()->has('etat')): ?>
            <p class="etat"><?php echo e(session()->get('etat')); ?></p>
        <?php endif; ?>
    <?php echo $__env->yieldSection(); ?>
    <?php $__env->startSection('errors'); ?>
        <?php if($errors->any()): ?>
            <div class="error">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php echo $__env->yieldSection(); ?>
        <?php echo $__env->yieldContent('contents'); ?>
    </body>
</html>

    <?php /**PATH /Users/nadertorjemane/Stock_MAMP/TM4-5/resources/views/modele.blade.php ENDPATH**/ ?>