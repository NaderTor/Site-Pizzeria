<?php $__env->startSection('contents'); ?>
    <p>Page d'accueil.</p>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nadertorjemane/Stock_MAMP/TM4-5/resources/views/home.blade.php ENDPATH**/ ?>