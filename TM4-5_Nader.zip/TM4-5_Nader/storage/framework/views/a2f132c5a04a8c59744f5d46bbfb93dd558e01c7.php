<?php $__env->startSection('contents'); ?>
    <p>Premiere page</p>
    
<?php $__env->startSection('contents'); ?>
<style>

    table,
    th,
    td {
        padding: 6px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }


    .BM,.Ajoubutton,.BS, .Ajout{
         background-color: blue;
        border: none;
        color: white;
        padding: 2px 5px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
    }
</style>


<?php if(auth()->guard()->check()): ?>
    <table>
        <th>id</th>
        <th>Nom</th>
        <th>description</th>
        <th>Prix</th>

        <?php $__currentLoopData = $pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr><td><?php echo e($pizza->id); ?></td><td><?php echo e($pizza->nom); ?></td><td><?php echo e($pizza->description); ?></td><td><?php echo e($pizza->prix); ?>e</td> 
            <td><a href="<?php echo e(route('ajouterPanier',['nom' => $pizza->nom])); ?>" class="Ajout" >Ajouter au panier</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nadertorjemane/Stock_MAMP/TM4-5/resources/views/main.blade.php ENDPATH**/ ?>