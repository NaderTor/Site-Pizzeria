<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;



class AuthenticatedSessionController extends Controller
{
    public function create(){
        return view('auth.login');
    }


    // login action
    public function store(Request $request){

        $request->validate([
            'login' => 'required|string',
            'mdp' => 'required|max:40'
            ]);


        $credentials = ['login' => $request->input('login'), 'password' => $request->input('mdp')];

        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();

            $request->session()->flash('etat','Login successful');

            return redirect()->route('Pizza');
        }
        return back()->withErrors([
            'login' => 'The provided credentials do not match our records.',
        ]);
    }

    // logout action
    public function destroy(Request $request){
        Auth::logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();


        return view("home");
    }


    public function Modifierform(){
        $user = AUTH::user();
        return view('auth.modifierform', ['u'=>$user]);
    }

    public function Modifier(Request $request){
        $user = AUTH::user();
        
        $validated = $request->validate([
            'mdp' => 'required|string|confirmed',
            ]);                                                
            $user->mdp = Hash::make($request->mdp);                                         
                                            

        $user->save();
        $request->session()->flash('etat', 'Modification effectuée !');         
        return redirect()->route('Pizza');
    
    }

}
