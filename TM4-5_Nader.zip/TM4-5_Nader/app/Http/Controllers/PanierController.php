<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\PizzasController;
use App\Models\Pizzas;
use Illuminate\Support\Facades\DB;


class PanierController extends Controller
{
    
    public function AfficherPanier(Request $request){
        $pizzas = Pizzas::all();
        $prixTotal = 0;
        $paniers = array();
//**
//* Determine if events and listeners should be automatically discovered.

//* @return bool

//public function shouldDiscoverEvents()
//{
  // return false;
//}
//}
        foreach($pizzas as $pizza){
            if($request->session()->has($pizza->nom)){
                $paniers[$pizza->nom] = ( $request->session()->get($pizza->nom));
                /*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
                $prixTotal = $prixTotal + (($pizza->prix)* $request->session()->get($pizza->nom));
            }
        }
        return view ('panier',['paniers'=>$paniers,'prixTotal'=>$prixTotal]);
    }


    public function AjouterPanier(Request $request){
        if($request->session()->has($request->nom)){
            /*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
            $qnt = $request->session()->get($request->nom);
            $request->session()->put($request->nom, $qnt+1);
            //public function shouldDiscoverEvents()
        //{
    // return false;
    //}
    //}
            return redirect()->route('afficherPanier');
        }
        $request->session()->put($request->nom, 1);
        return redirect()->route('afficherPanier');
    }


    public function AugmenterLaQuantite(Request $request){
        $qnt = $request->session()->put($request->nom);
        /*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
            $request->session()->put($request-> nom, $qnt+1);
            return redirect()->route('panier');
    }
}




