<?php

namespace App\Http\Controllers;

use App\Models\Pizzas;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PizzasController extends Controller
{

    public function Pizza(){
        $pizzas = DB::table('pizzas')->get();
        return view('main',['pizzas'=>$pizzas]);
    }

    public function VoirMenu(){
        $pizzas = Pizzas::all();
        return view('admin.admin_home', ['pizzas'=>$pizzas]);
    }

    public function CreateForm() {
        return view('pizza.createForm');
    }

    public function Create(Request $request) {
        $validated = $request->validate([              
        'nom' => 'required|alpha|max:40',                       
        'description' => 'required|max:100',
        'prix' => 'bail|required|integer|gte:0|lte:120',
        ]);
    
        $pizzas = new Pizzas();
        $pizzas->nom = $validated['nom'];
        $pizzas->description = $validated['description'];
        $pizzas->prix = $validated['prix']; 

        $pizzas->save();
        $request->session()->flash('etat', 'Ajout effectuée !');

        return redirect()->route('Pizza');
    }

    public function DeleteForm($id) {
        $pizza = Pizza::findOrFail($id);
        return view('pizza.deleteForm', ['nom'=>$pizza]);
    }

    public function Delete(Request $request,$id) {
        $pizzas = Pizza::findOrFail($id);
        if($request->has('oui')){
            $pizzas->delete();
            $request->session()->flash('etat', 'Suppression effectuée !');
        }else{
            $request->session()->flash('etat', 'Suppression annulée !');
        }
        return redirect()->route('delete');
    }

    public function ModifyForm($id) {
        $pizzas = Pizzas::findOrFail($id);

        return view('pizza.modifyForm', ['pizzas'=>$pizzas]);
    }
   
    public function Modify(Request $request) {
        $pizzas = Pizzas::where('id',[$request->id])->first();
        
        $validated = $request->validate([
            'nom' => 'required|alpha|max:40',
            'description' => 'required|max:100',
            'prix' => 'bail|required|integer|gte:0|lte:120',
            ]);
                                                             
        $pizzas->nom = $validated['nom'];                                         
        $pizzas->description = $validated['description'];                                
        $pizzas->prix = $validated['prix'];                                        

        $pizzas->save();
        $request->session()->flash('etat', 'Modification effectuée !');         
        return redirect()->route('Pizza');
    }

}
