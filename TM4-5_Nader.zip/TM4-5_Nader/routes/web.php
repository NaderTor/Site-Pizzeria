<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthenticatedSessionController;
use App\Http\Controllers\RegisterUserController;
use App\Http\Controllers\PizzasController;
use App\Http\Controllers\PanierController;



/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [PizzasController::class, 'Pizza'])->name('Pizza');

Route::view('/home','home');

Route::get('/admin', [PizzasController::class, 'VoirMenu'])->name('admin_home')->middleware('auth')->middleware('is_admin');



Route::get('/login', [AuthenticatedSessionController::class,'create'])->name('login');

Route::post('/login', [AuthenticatedSessionController::class,'store']);

Route::get('/logout', [AuthenticatedSessionController::class,'destroy'])->name('logout')->middleware('auth');

Route::get('/register', [RegisterUserController::class,'create'])->name('register');

Route::post('/register', [RegisterUserController::class,'store']);



Route::get('/modify/{id}', [PizzasController::class, 'ModifyForm'])->name('modifyForm');
Route::post('/modify/{id}', [PizzasController::class, 'Modify'])->name('modify');

Route::get('/delete/{id}', [PizzasController::class, 'DeleteForm'])->name('deleteForm');
Route::post('/delete/{id}', [PizzasController::class, 'Delete'])->name('delete');

Route::get('/create', [PizzasController::class, 'CreateForm'])->name('createForm');
Route::post('/create', [PizzasController::class, 'Create'])->name('create');

Route::get('/modifier',[AuthenticatedSessionController::class, 'ModifierForm'])->name('modifierForm');
Route::post('/modifier',[AuthenticatedSessionController::class, 'Modifier'])->name('modifier');

Route::get('/panier', [PanierController::class, 'AfficherPanier'])->name('afficherPanier');

Route::get('/ajouter',[PanierController::class, 'AjouterPanier'])->name('ajouterPanier');

Route::get('/augmenter',[PanierController::class, 'AugmenterLaQuantite'])->name('augmenterLaQuantite');